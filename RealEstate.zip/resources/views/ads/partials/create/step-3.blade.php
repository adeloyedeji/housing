<h3>Upload Pictures</h3>
<div class="row">
    <div class="col-md-12">
        <div class="dropzone" id="upload_photos"></div>
    </div>
</div>
<br>