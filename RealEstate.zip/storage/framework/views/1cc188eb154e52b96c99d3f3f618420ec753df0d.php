<div class="col-md-12 clear"> 
    <?php if(session()->has('search')): ?>
        <?php if(session('search') == 1): ?>
            <h3 class="panel-title">
                We found '<?php echo e(count($ads)); ?>' matching results
                <hr>
            </h3>
        <?php endif; ?>
    <?php endif; ?>
    <div id="list-type" class="proerty-th">
        <?php if( count($ads) > 0 ): ?>
            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $image = "img/house.png";
                    if( count($ad->adImage) > 0 ) {
                        foreach($ad->adImage as $adimage) {
                            $image = $adimage->image;
                        }
                    }
                ?>
                <div class="col-sm-6 col-md-3 p0">
                    <div class="box-two proerty-item">
                        <div class="item-thumb">
                            <a href="<?php echo e(url('ads/result')); ?>/<?php echo e($ad->slug); ?>" ><img src="<?php echo e(asset('')); ?>/<?php echo e($image); ?>" style="100%;height:243px;"></a>
                        </div>

                        <div class="item-entry overflow">
                            <h5>
                                <a class="text-house" href="<?php echo e(url('ads/result')); ?>/<?php echo e($ad->slug); ?>" style="text-transform:none"> 
                                    <?php echo e(ucwords(Utility::short_title($ad->title))); ?> 
                                </a>
                            </h5>
                            <div class="dot-hr"></div>
                            <span class="pull-left"><b> Date :</b> <?php echo e($ad->created_at->diffForHumans()); ?> </span>
                            <span class="proerty-price pull-right"> N <?php echo e(number_format($ad->max_rent)); ?></span>
                            <p style="display: none;" class="text-house">
                                <b>
                                    <?php echo e(Utility::short_description($ad->description)); ?>

                                </b>
                            </p>
                            <div class="property-icon" style="width:100%;background-color:#ffffff">
                                <img src="<?php echo e(asset('img/icon/bed.png')); ?>"> <?php echo e($ad->max_bed); ?>&emsp;
                                <img src="<?php echo e(asset('img/icon/shawer.png')); ?>"> <?php echo e($ad->max_bath); ?>

                            </div>
                        </div>
                        <div></div>
                    </div>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <center><h3>Be the first to post an ad</h3></center>
        <?php endif; ?>
    </div>
</div>

<div class="col-md-12"> 
    <div class="pull-right">
        <div class="pagination">
            <?php echo e($ads->links()); ?>

        </div>
    </div>                
</div>