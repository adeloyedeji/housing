<?php $__env->startSection('title'); ?>
    | Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head"> 
    <div class="container">
        <div class="row">
            <div class="page-head-content">
                <h1 class="page-title">Hello : <span class="orange strong"><?php echo e(\Auth::user()->fname); ?> <?php echo e(\Auth::user()->lname); ?></span></h1>
            </div>
        </div>
    </div>
</div>

<div class="content-area user-profiel" style="background-color: #FCFCFC;">&nbsp;
    <div class="container">   
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 profiel-container">

                <form action="<?php echo e(url('profile')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="profiel-header">
                        <h3>
                            <b>BUILD</b> YOUR PROFILE <br>
                            <small>Your information will help others to contact you on ads.</small>
                        </h3>
                        <?php if( session()->has('status')): ?>
                            <div class="alert alert-success alert-dismissable"  id="alert_warn">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <span id="alert_warn_msg"><?php echo e(session('status')); ?></span>
                            </div>
                        <?php endif; ?>
                        <hr>
                    </div>

                    <div class="clear">
                        <div class="col-sm-3 col-sm-offset-1">
                            <div class="picture-container">
                                <div class="picture">
                                    <img src="<?php echo e(asset('')); ?><?php echo e(\Auth::user()->image); ?>" class="picture-src" id="wizardPicturePreview" title="<?php echo e(\Auth::user()->fname); ?> <?php echo e(\Auth::user()->lname); ?>" style="width:100%;height:100%">
                                </div>
                                <div class="form-group <?php echo e($errors->has('profile') ? ' has-error' : ''); ?>">
                                    <label for="profile">Change profile photo :</label>
                                    <input class="form-control" type="file" name="profile" id="profile" value="<?php echo e(old('profile')); ?>">
                                    <?php if($errors->has('profile')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('profile')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3 padding-top-25">

                            <div class="form-group <?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                                <label>First Name <small>(required)</small></label>
                                <input name="first_name" type="text" class="form-control" placeholder="Andrew..." value="<?php echo e(\Auth::user()->fname); ?>" required>
                                <?php if($errors->has('first_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                                <label>Last Name <small>(required)</small></label>
                                <input name="last_name" type="text" class="form-control" placeholder="Smith..." value="<?php echo e(\Auth::user()->lname); ?>" required>
                                <?php if($errors->has('lastname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>  
                        </div>
                        <div class="col-sm-3 padding-top-25">
                            <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label>Email <small>(required)</small></label>
                                <input name="email" type="email" class="form-control" placeholder="andrew@email@email.com.com" value="<?php echo e(\Auth::user()->email); ?>" required disabled>
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                                <label>Phone <small>(required)</small></label>
                                <input name="phone" type="text" class="form-control" placeholder="08107654663" value="<?php echo e($profile->phone1); ?>" required>
                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>  
                        <div class="col-sm-3 padding-top-25">
                            <div class="form-group <?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                <label>Username <small>(required)</small></label>
                                <input name="username" type="text" class="form-control" value="<?php echo e(\Auth::user()->username); ?>" required>
                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>

                    <div class="clear">
                        <br>
                        <hr>
                        <br>
                        <div class="col-sm-5 col-sm-offset-1">
                            <div class="form-group <?php echo e($errors->has('facebook_handle') ? ' has-error' : ''); ?>">
                                <label>Facebook :</label>
                                <input name="facebook_handle" type="text" class="form-control" placeholder="https://facebook.com/user" value="<?php echo e($social->facebook); ?>">
                                <?php if($errors->has('facebook_handle')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('facebook_handle')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('twitter_handle') ? ' has-error' : ''); ?>">
                                <label>Twitter :</label>
                                <input name="twitter_handle" type="text" class="form-control" placeholder="https://Twitter.com/@user" value="<?php echo e($social->twitter); ?>">
                                <?php if($errors->has('twitter_handle')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('twitter_handle')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('google_handle') ? ' has-error' : ''); ?>">
                                <label>Google :</label>
                                <input name="google_handle" type="text" class="form-control" placeholder="https://plus.google.com/" value="<?php echo e($social->google); ?>">
                                <?php if($errors->has('google_handle')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('google_handle')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>  

                        <div class="col-sm-5">
                            <div class="form-group <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                                <label>Address :</label>
                                <input name="address" type="text" class="form-control" placeholder="E.g. 5, broad street" value="<?php echo e($profile->current_address); ?>" required>
                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                                <label>City :</label>
                                <input name="city" type="text" class="form-control" placeholder="CMS" value="<?php echo e($profile->city); ?>" required>
                                <?php if($errors->has('city')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                                <label>State :</label>
                                <select id="state" name="state" class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Select state" required>
                                    <?php if( count($states) > 0 ): ?>
                                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $profile->state_id == $state->id ): ?>
                                                <option value="<?php echo e($state->id); ?>" selected><?php echo e($state->state); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                            <option value="0">Empty</option>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('state')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('state')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                        </div>

                        <div class="col-sm-10 col-sm-offset-1">
                            <div class="form-group <?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
                                <label>Country :</label>
                                <select id="country" name="country" class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Select Country" required>
                                    <?php if( count($countries) > 0 ): ?>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $profile->country_id == $country->id ): ?>
                                                <option value="<?php echo e($country->id); ?>" selected><?php echo e($country->country); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                            <option value="0">Empty</option>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('country')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('about') ? ' has-error' : ''); ?>">
                                <label>About Me</label>
                                <textarea class="form-control" name="about" id="about" required placeholder="A little about myself" style="height:200px"><?php echo e($profile->about); ?></textarea>
                                <?php if($errors->has('about')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('about')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
            
                    <div class="col-sm-5 col-sm-offset-1">
                        <br>
                        <input type='submit' class='btn btn-finish btn-primary' name='finish' value='Finish' />
                    </div>
                    <br>
            </form>

        </div>
    </div><!-- end row -->

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>