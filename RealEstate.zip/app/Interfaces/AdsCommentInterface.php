<?php

namespace App\Interfaces;

interface AdsCommentInterface {
    
}