<?php $__env->startSection('title'); ?>
    | Login / Register
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head"> 
    <div class="container">
        <div class="row">
            <div class="page-head-content">
                <h1 class="page-title">Sign in / New account </h1>               
            </div>
        </div>
    </div>
</div>
<!-- End page header -->


<!-- register-area -->
<div class="register-area" style="background-color: rgb(249, 249, 249);">
    <div class="container">
        <div class="col-md-6">
            <div class="box-for overflow">
                <div class="col-md-12 col-xs-12 register-blocks">
                    <h2>New account : </h2> 
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="col-md-6">
                            <div class="form-group<?php echo e($errors->has('fname') ? ' has-error' : ''); ?>">
                                <label for="name">First name</label>
                                <input type="text" class="form-control" id="fname" name="fname" value="<?php echo e(old('lname')); ?>">
                                <?php if($errors->has('fname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group<?php echo e($errors->has('lname') ? ' has-error' : ''); ?>">
                                <label for="name">Last name</label>
                                <input type="text" class="form-control" id="lname" name="lname" value="<?php echo e(old('lname')); ?>">
                                <?php if($errors->has('lname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group <?php if( session()->has('auth_sess') && session('auth_sess') == 1): ?> <?php echo e($errors->has('email') ? ' has-error' : ''); ?> <?php endif; ?>">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
                                <?php if(session()->has('auth_sess') && session('auth_sess') == 1): ?>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" value="<?php echo e(old('username')); ?>">
                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php if(session()->has('auth_sess') && session('auth_sess') == 1): ?> <?php echo e($errors->has('password') ? ' has-error' : ''); ?> <?php endif; ?>">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password">
                                <?php if(session()->has('auth_sess') && session('auth_sess') == 1): ?>
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password-confirm">Confirm Password</label>
                                <input type="password" class="form-control" id="password-confirm" name="password_confirmation">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="control-label">I am</label>
                                <div class="radio-inline">
                                    <label>
                                        <input type="radio" name="gender" id="gender_male" value="1">A Male
                                    </label>
                                </div>
                                <div class="radio-inline">
                                    <label>
                                        <input type="radio" name="gender" id="gender_female" value="0">A Female
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-default">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box-for overflow">                         
                <div class="col-md-12 col-xs-12 login-blocks">
                    <h2>Login : </h2> 
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group <?php if(session()->has('auth_sess') && session('auth_sess') == 2): ?> <?php echo e($errors->has('email') ? ' has-error' : ''); ?> <?php endif; ?>">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
                            <?php if(session()->has('auth_sess') && session('auth_sess') == 2): ?>
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?php if(session()->has('auth_sess') && session('auth_sess') == 2): ?> <?php echo e($errors->has('password') ? ' has-error' : ''); ?> <?php endif; ?>">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password">
                            <?php if(session()->has('auth_sess') && session('auth_sess') == 2): ?>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember me on this device
                            </label>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-default"> Log in</button>
                            <a href="<?php echo e(route('password.request')); ?>">Forgot Password</a>
                        </div>
                    </form>
                    <br>
                    
                    <h2>Social login :  </h2> 
                    
                    <p>
                    <a class="login-social" href="#"><i class="fa fa-facebook"></i>&nbsp;Facebook</a> 
                    <a class="login-social" href="#"><i class="fa fa-google-plus"></i>&nbsp;Gmail</a> 
                    <a class="login-social" href="#"><i class="fa fa-twitter"></i>&nbsp;Twitter</a>  
                    </p> 
                </div>
                
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>