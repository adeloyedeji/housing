<div class="wizard-card ct-wizard-orange" id="wizardProperty">
    <form action="<?php echo e(url('ads')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="wizard-header">
            <h3>
                <b>Post</b> A NEW ADVERT  <br>
                <small>Fill in the form below to post your ad and start getting feedbacks.</small>
            </h3>
        </div>

        <?php if( session()->has('post-ad') ): ?>
            <div class="alert alert-warning alert-dismissable"  id="alert_warn">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <span id="alert_warn_msg"><?php echo e(session('post-ad')); ?></span>
            </div>
        <?php endif; ?>
        
        <ul>
            <li><a href="#step1" data-toggle="tab">Room for rent </a></li>
            <li><a href="#step2" data-toggle="tab">Features </a></li>
            <!--<li><a href="#step3" data-toggle="tab">Room mate </a></li>-->
            <li><a href="#step4" data-toggle="tab">Photo </a></li>
            <li><a href="#step5" data-toggle="tab">Finalization </a></li>
        </ul>

        <div class="tab-content">

            <?php echo $__env->make('ads.partials.post.step1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--  End step 1 -->

            <?php echo $__env->make('ads.partials.post.step2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- End step 2 -->

            <!--<?php echo $__env->make('ads.partials.post.step3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>-->
            <!--  End step 3 -->

            <?php echo $__env->make('ads.partials.post.step4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--  End step 4 -->
            
            <?php echo $__env->make('ads.partials.post.step5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--  End step 4 -->

        </div>

        <div class="wizard-footer">
            <div class="pull-right">
                <input type='button' class='btn btn-next btn-primary' name='next' value='Next' />
                <input type='submit' class='btn btn-finish btn-primary ' name='finish' value='Finish' />
            </div>

            <div class="pull-left">
                <input type='button' class='btn btn-previous btn-default' name='previous' value='Previous' />
            </div>
            <div class="clearfix"></div>                                            
        </div>	
    </form>
</div>