<div class="row">
    <div class="col-md-12">
        <p>{{ $ad->description }}</p>
        <hr>
    </div>
</div>