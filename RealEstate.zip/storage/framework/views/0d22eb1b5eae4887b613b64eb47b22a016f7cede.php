<?php $__env->startSection('title'); ?>
    | Reset Password
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head"> 
    <div class="container">
        <div class="row">
            <div class="page-head-content">
                <h1 class="page-title">Reset Your Password</h1>              
            </div>
        </div>
    </div>
</div>

<div class="content-area user-profiel" style="background-color: #FCFCFC;">&nbsp;
    <div class="container">   
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 profiel-container">

                <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>


                    <div class="profiel-header">
                        <h3>
                            <b>UPDATE</b> YOUR PASSWORD <br>
                            <small>Fill in the fields below to update your password.</small>
                        </h3>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <hr>
                    </div>

                    <div class="clear">

                        <div class="col-sm-10 col-sm-offset-1">
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email">E-Mail Address <small>(required)</small></label>

                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-sm-10 col-sm-offset-1">
                            <input type='submit' class='btn btn-finish btn-primary pull-right' value='Send Password Reset Link' />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div><!-- end row -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>