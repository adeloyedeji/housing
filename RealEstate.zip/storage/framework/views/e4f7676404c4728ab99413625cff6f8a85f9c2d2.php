<div class="tab-pane" id="step1">
    <div class="row p-b-15  ">
        <h4 class="info-text"> Let's start with the basic information</h4>
        <label class="radio-inline"><input type="radio" id="need_room" name="room_option" value="1" checked>&nbsp;I need a room mate</label>
        <hr>
        <br>
        <div class="col-sm-12 col-md-12">
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                    <label for="state">State <small>(required)</small></label>
                    <?php $states = \Utility::getState('all'); ?>
                    <select id="state" name="state" class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Select state" required>
                        <?php if( count($states) > 0 ): ?>
                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( old('state') == $state->id ): ?>
                                    <option value="<?php echo e($state->id); ?>" selected><?php echo e($state->state); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                                <option value="0">Empty</option>
                        <?php endif; ?>
                    </select>
                    <?php if($errors->has('state')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('state')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
                    <label for="location">Location <small>(required)</small></label>
                    <input name="location" id="location" type="text" class="form-control" placeholder="Super villa ..." value="<?php echo e(old('location')); ?>" required>
                    <?php if($errors->has('location')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('location')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-12">
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('move_on') ? ' has-error' : ''); ?>">
                    <label for="move_on">I intend to move on <small>(required)</small></label>
                    <input type="text" class="form-control datepicker" id="move_on" name="move_on" value="<?php echo e(old('move_on')); ?>" required>
                    <?php if($errors->has('move_on')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('move_on')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('room_type') ? ' has-error' : ''); ?>">
                    <label for="room_type">Room Type <small>(required)</small></label>
                    <select id="room_type" name="room_type" class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Select room type" required>
                        <option <?php if( old('room_type') == "Bungalow" ): ?> selected <?php endif; ?> value="Bungalow">Bungalow</option>
                        <option <?php if( old('room_type') == "Duplex" ): ?> selected <?php endif; ?> value="Duplex">Duplex</option>
                        <option <?php if( old('room_type') == "Flat / Apartment" ): ?> selected <?php endif; ?> value="Flat / Apartment">Flat / Apartment</option>
                        <option <?php if( old('room_type') == "House" ): ?> selected <?php endif; ?> value="House">House</option>
                        <option <?php if( old('room_type') == "Land" ): ?> selected <?php endif; ?> value="Land">Land</option>
                        <option <?php if( old('room_type') == "Office Space" ): ?> selected <?php endif; ?> value="Office Space">Office Space</option>
                        <option <?php if( old('room_type') == "Self Contain" ): ?> selected <?php endif; ?> value="Self Contain">Self Contain</option>
                        <option <?php if( old('room_type') == "Shop" ): ?> selected <?php endif; ?> value="Shop">Shop</option>
                    </select>
                    <?php if($errors->has('room_type')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('room_type')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>