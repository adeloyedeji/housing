<div class="tab-pane" id="step4">                                        
    <h4 class="info-text">Upload images. Your ad will attract more attention if it has images </h4>
    <div class="row">  
        <div class="col-sm-12">
            <div class="form-group <?php echo e($errors->has('image1') ? ' has-error' : ''); ?>">
                <label for="image1">Chose Image :</label>
                <input class="form-control" type="file" name="image1" id="image1" value="<?php echo e(old('image1')); ?>">
                <?php if($errors->has('image1')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('image1')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">  
        <div class="col-sm-12">
            <div class="form-group <?php echo e($errors->has('image2') ? ' has-error' : ''); ?>">
                <label for="image2">Chose Image :</label>
                <input class="form-control" type="file" name="image2" id="image2" value="<?php echo e(old('image2')); ?>">
                <?php if($errors->has('image2')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('image2')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">  
        <div class="col-sm-12">
            <div class="form-group <?php echo e($errors->has('image3') ? ' has-error' : ''); ?>">
                <label for="image3">Chose Image :</label>
                <input class="form-control" type="file" name="image3" id="image3" value="<?php echo e(old('image3')); ?>">
                <?php if($errors->has('image3')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('image3')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">  
        <div class="col-sm-12">
            <div class="form-group <?php echo e($errors->has('image4') ? ' has-error' : ''); ?>">
                <label for="image4">Chose Image :</label>
                <input class="form-control" type="file" name="image4" id="image4" value="<?php echo e(old('image4')); ?>">
                <?php if($errors->has('image4')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('image4')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">  
        <div class="col-sm-12">
            <div class="form-group <?php echo e($errors->has('image5') ? ' has-error' : ''); ?>">
                <label for="image5">Chose Image :</label>
                <input class="form-control" type="file" name="image5" id="image5" value="<?php echo e(old('image5')); ?>">
                <?php if($errors->has('image5')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('image5')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>