<?php $__env->startSection('title'); ?>
    | Post new ad
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/wizard.css')); ?>">
<div class="page-head"> 
    <div class="container">
        <div class="row">
            <div class="page-head-content">
                <h1 class="page-title">Post a new Ad</h1>               
            </div>
        </div>
    </div>
</div>

<div class="content-area submit-property" style="background-color: #FCFCFC;">&nbsp;
    <div class="container">
        <div class="clearfix" > 
            <div class="wizard-container"> 

                <?php echo $__env->make('ads.partials.post.wizard-section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- End submit form -->
            </div> 
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>