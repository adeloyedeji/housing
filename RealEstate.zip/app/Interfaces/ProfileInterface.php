<?php

namespace App\Interfaces;

interface ProfileInterface {
    
}
