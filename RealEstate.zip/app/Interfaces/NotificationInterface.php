<?php

namespace App\Interfaces;

interface NotificationInterface {
    
}