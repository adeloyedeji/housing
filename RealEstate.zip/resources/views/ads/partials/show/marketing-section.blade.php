<div class="panel panel-default sidebar-menu wow fadeInRight animated">
    <div class="panel-heading">
        <h3 class="panel-title">Ads here  </h3>
    </div>
    <div class="panel-body recent-property-widget">
        <img src="{{ asset('img/ads.jpg') }}">
    </div>
</div>