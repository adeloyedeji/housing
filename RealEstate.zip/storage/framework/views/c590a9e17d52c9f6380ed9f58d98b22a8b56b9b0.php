<div class="tab-pane" id="step3">
    <h4 class="info-text"> Room mate options </h4>
    <label class="radio-inline" onclick="need_roommate()">
        <input type="radio" id="need_roommate" name="roomate_option" value="1" checked>&nbsp;I would also need a roommate
    </label>
    <label class="radio-inline" onclick="dont_need_roommate()">
        <input type="radio" id="dont_need_roommate" name="roomate_option" value="0">&nbsp;I don't need a roommate
    </label>
    <div id="optional">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('total_roommate') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="total_roommate">Total room mates</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="total_roommate" name="total_roommate">
                        <?php for($i = 1; $i <= 10; $i++): ?>
                            <?php if( old('total_roommate') == $i ): ?>
                               <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option> 
                            <?php else: ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                    <?php if($errors->has('total_roommate')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('total_roommate')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('roommate_gender') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="roommate_gender">Gender</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="roommate_gender" name="roommate_gender">
                        <option <?php if( old('roommate_gender') == "1" ): ?> selected <?php endif; ?> value="1">Doesn't Matter</option>
                        <option <?php if( old('roommate_gender') == "Male" ): ?> selected <?php endif; ?> value="Male">Male</option>
                        <option <?php if( old('roommate_gender') == "Female" ): ?> selected <?php endif; ?> value="Female">Female</option>
                    </select>
                    <?php if($errors->has('roommate_gender')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('roommate_gender')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('rommate_age') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="rommate_age">Age</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="rommate_age" name="rommate_age">
                        <option <?php if( old('rommate_age') == "1" ): ?> selected <?php endif; ?> value="1">Doesn't Matter</option>
                        <option <?php if( old('rommate_age') == "16-20" ): ?> selected <?php endif; ?> value="16-20">16-20</option>
                        <option <?php if( old('rommate_age') == "21-25" ): ?> selected <?php endif; ?> value="21-25">21-25</option>
                        <option <?php if( old('rommate_age') == "26-35" ): ?> selected <?php endif; ?> value="26-35">26-35</option>
                        <option <?php if( old('rommate_age') == "35-46" ): ?> selected <?php endif; ?> value="35-46">35-46</option>
                        <option <?php if( old('rommate_age') == "46+" ): ?> selected <?php endif; ?> value="46+">46+</option>
                    </select>
                    <?php if($errors->has('rommate_age')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('rommate_age')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('rommate_marital_status') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="rommate_marital_status">Marital Status</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="rommate_marital_status" name="rommate_marital_status">
                        <option <?php if( old('rommate_marital_status') == "1" ): ?> selected <?php endif; ?> value="1">Doesn't Matter</option>
                        <option <?php if( old('rommate_marital_status') == "Single" ): ?> selected <?php endif; ?> value="Single">Single </option>
                        <option <?php if( old('rommate_marital_status') == "In a relationship" ): ?> selected <?php endif; ?> value="In a relationship">In a relationship</option>
                        <option <?php if( old('rommate_marital_status') == "Engaged" ): ?> selected <?php endif; ?> value="Engaged">Engaged</option>
                        <option <?php if( old('rommate_marital_status') == "Married" ): ?> selected <?php endif; ?> value="Married">Married</option>
                        <option <?php if( old('rommate_marital_status') == "Widow / Widower" ): ?> selected <?php endif; ?> value="Widow / Widower">Widow / Widower</option>
                    </select>
                    <?php if($errors->has('rommate_marital_status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('rommate_marital_status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('rommate_employment_status') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="rommate_employment_status">Employment Status</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="rommate_employment_status" name="rommate_employment_status">
                        <option <?php if( old('rommate_employment_status') == "1" ): ?> selected <?php endif; ?> value="1">Doesn't Matter</option>
                        <option <?php if( old('rommate_employment_status') == "Student" ): ?> selected <?php endif; ?> value="Student">Student </option>
                        <option <?php if( old('rommate_employment_status') == "Employed" ): ?> selected <?php endif; ?> value="Employed">Employed</option>
                        <option <?php if( old('rommate_employment_status') == "Self Employed / Freelance" ): ?> selected <?php endif; ?> value="Self Employed / Freelance">Self Employed / Freelance</option>
                        <option <?php if( old('rommate_employment_status') == "Unemployed" ): ?> selected <?php endif; ?> value="Unemployed">Unemployed</option>
                        <option <?php if( old('rommate_employment_status') == "Other" ): ?> selected <?php endif; ?> value="Other">Other</option>
                    </select>
                    <?php if($errors->has('rommate_employment_status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('rommate_employment_status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('rommate_smoking_status') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="rommate_smoking_status">Is a somker</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="rommate_smoking_status" name="rommate_smoking_status">
                        <option <?php if( old('rommate_smoking_status') == "1" ): ?> selected <?php endif; ?> value="1">Doesn't Matter</option>
                        <option <?php if( old('rommate_smoking_status') == "Yes" ): ?> selected <?php endif; ?> value="Yes">Yes </option>
                        <option <?php if( old('rommate_smoking_status') == "No" ): ?> selected <?php endif; ?> value="No">No</option>
                    </select>
                    <?php if($errors->has('rommate_smoking_status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('rommate_smoking_status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('rommate_pets_status') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="rommate_pets_status">Has Pets</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="rommate_pets_status" name="rommate_pets_status">
                        <option <?php if( old('rommate_pets_status') == "1" ): ?> selected <?php endif; ?> value="1">Doesn't Matter</option>
                        <option <?php if( old('rommate_pets_status') == "Yes" ): ?> selected <?php endif; ?> value="Yes">Yes </option>
                        <option <?php if( old('rommate_pets_status') == "No" ): ?> selected <?php endif; ?> value="No">No</option>
                    </select>
                    <?php if($errors->has('rommate_pets_status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('rommate_pets_status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group <?php echo e($errors->has('rommate_kids_status') ? ' has-error' : ''); ?>">
                    <label class="control-label" for="rommate_kids_status">Has kids</label>
                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" required id="rommate_kids_status" name="rommate_kids_status">
                        <option <?php if( old('rommate_kids_status') == "1" ): ?> selected <?php endif; ?> value="1">Doesn't Matter</option>
                        <option <?php if( old('rommate_kids_status') == "Yes" ): ?> selected <?php endif; ?> value="Yes">Yes </option>
                        <option <?php if( old('rommate_kids_status') == "No" ): ?> selected <?php endif; ?> value="No">No</option>
                    </select>
                    <?php if($errors->has('rommate_kids_status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('rommate_kids_status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/jquery-1.10.2.min.js')); ?>"></script>
<script>
    function need_roommate() {
        $("#optional").fadeIn("slow");
    }

    function dont_need_roommate() {
        $("#optional").fadeOut("slow");
    }
</script>