<?php $__env->startSection('title'); ?>
    | Properties
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-head"> 
    <div class="container">
        <div class="row">
            <div class="page-head-content">
                <h1 class="page-title">Browse ads gallery</h1>               
            </div>
        </div>
    </div>
</div>


<div class="properties-area recent-property" style="background-color: #FFF;">
    <div class="container">  
        <div class="row  pr0 padding-top-40 properties-page">

            <?php echo $__env->make('ads.partials.index.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('ads.partials.index.search-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('ads.partials.index.body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>              
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>