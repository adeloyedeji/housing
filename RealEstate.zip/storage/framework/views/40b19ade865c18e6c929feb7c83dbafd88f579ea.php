<nav class="navbar navbar-default ">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/housemait/logo.jpg')); ?>" alt="" style=""></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse yamm" id="navigation">
            <div class="button navbar-right">
                <?php if(\Auth::check()): ?>
                    <button class="navbar-btn nav-button wow bounceInRight login" href="<?php echo e(route('logout')); ?>" data-wow-delay="0.55s"
                        onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                        Logout
                    </button>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                <?php else: ?>
                    <button class="navbar-btn nav-button wow bounceInRight login" onclick="window.open('<?php echo e(route('login')); ?>')" data-wow-delay="0.45s">Login / Register</button>
                <?php endif; ?>
                <button class="navbar-btn nav-button wow fadeInRight" onclick="window.open('<?php echo e(url('ads/create')); ?>')" data-wow-delay="0.58s">Post an ad</button>
            </div>
            <ul class="main-nav nav navbar-nav navbar-right">
                <li class="ymm-sw " data-wow-delay="0.1s">
                    <a href="<?php echo e(url('/')); ?>" <?php if( active('/') ): ?> class="active" <?php endif; ?>>Browse</a>
                </li>

                <li class="wow fadeInDown" data-wow-delay="0.2s">
                    <a <?php if( active('ads/*') ): ?> class="active" <?php endif; ?> href="<?php echo e(url('ads')); ?>">Adverts</a>
                </li>
                
                <?php if( \Auth::check()): ?>

                <li class="dropdown ymm-sw " data-wow-delay="0.3s">
                    <a href="#" class="dropdown-toggle  <?php if( active('user/*') ): ?> active <?php endif; ?>" data-toggle="dropdown" data-hover="dropdown" data-delay="200">My Account <b class="caret"></b></a>
                    <ul class="dropdown-menu navbar-nav">
                        <li>
                            <a href="<?php echo e(url('home')); ?>">My Ads</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('profile')); ?>">Profile</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('profile/update-password')); ?>">Update Password</a>
                        </li>
                    </ul>
                </li>

                <li class="ymm-sw " data-wow-delay="0.4s">
                    <a href="<?php echo e(url('notification/me')); ?>" <?php if( active('notification/me') ): ?> class="active" <?php endif; ?>>
                        Notification
                        <span class="badge"><?php echo e(count(\Auth::user()->unreadNotifications)); ?></span>
                    </a>
                </li>
                    
                <?php endif; ?>

                <li class="wow fadeInDown" data-wow-delay="0.6s"><a href="<?php echo e(url('contact')); ?>"  <?php if( active('contact') ): ?> class="active" <?php endif; ?>>Contact</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>