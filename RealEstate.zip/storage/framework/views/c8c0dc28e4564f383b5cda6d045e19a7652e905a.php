<div class="tab-pane" id="step2">
    <h4 class="info-text"> Tell us more about your ad </h4>
    <div class="row">
        <div class="col-sm-12"> 
            <div class="col-sm-12"> 
                <div class="form-group <?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                    <label for="title">Title <small>(required)</small>:</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="E.g. 2 Bedroom flat for rent" value="<?php echo e(old('title')); ?>" required>
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div> 
            </div> 
        </div>
        <div class="col-sm-12"> 
            <div class="col-sm-12"> 
                <div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                    <label for="description">Property Description <small>(required)</small>:</label>
                    <textarea  class="form-control" id="description" name="description" required placeholder="Write brief description here"><?php echo e(old('description')); ?></textarea>
                    <?php if($errors->has('description')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div> 
            </div> 
        </div>

        <div class="col-sm-12">
            <div class="col-sm-3">
                <div class="form-group <?php echo e($errors->has('total_units') ? ' has-error' : ''); ?>">
                    <label for="total_units">Total Rooms <small>(required)</small> :</label>
                    <select id="total_units" name="total_units" class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Pick an option" required>
                        <?php for($i = 1; $i <= 10; $i++): ?>
                            <?php if( old('total_units') == $i ): ?>
                               <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option> 
                            <?php else: ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                    <?php if($errors->has('total_units')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('total_units')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group <?php echo e($errors->has('bathrooms') ? ' has-error' : ''); ?>">
                    <label for="bathrooms">Bathrooms <small>(required)</small>:</label>
                    <select id="bathrooms" name="bathrooms" class="selectpicker" data-live-search="true" data-live-search-style="begins" title="pick an option" required>
                        <?php for($i = 1; $i <= 10; $i++): ?>
                            <?php if( old('bathrooms') == $i ): ?>
                               <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option> 
                            <?php else: ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                    <?php if($errors->has('bathrooms')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('bathrooms')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group <?php echo e($errors->has('bedrooms') ? ' has-error' : ''); ?>">
                    <label for="bedrooms">Bedrooms  <small>(required)</small>:</label>
                    <select id="bedrooms" name="bedrooms" class="selectpicker show-tick form-control" data-live-search="true" data-live-search-style="begins" title="pick an option" required>
                        <?php for($i = 1; $i <= 10; $i++): ?>
                            <?php if( old('bedrooms') == $i ): ?>
                               <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option> 
                            <?php else: ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                    <?php if($errors->has('bedrooms')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('bedrooms')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group <?php echo e($errors->has('toilets') ? ' has-error' : ''); ?>">
                    <label for="toilets">Toilets  <small>(required)</small>:</label>
                    <select id="toilets" name="toilets" class="selectpicker show-tick form-control" data-live-search="true" data-live-search-style="begins" title="pick an option" required>
                        <?php for($i = 1; $i < 10; $i++): ?>
                            <?php if( old('toilets') == $i ): ?>
                               <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option> 
                            <?php else: ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                    <?php if($errors->has('toilets')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('toilets')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-sm-12 padding-top-15"> 
            <div class="col-sm-12 col-md-6">
                <div class="form-group <?php echo e($errors->has('price_range') ? ' has-error' : ''); ?>">
                    <label for="price_range">My budget is <small>(required) including other charges</small> :</label>
                    <input type="number" class="form-control" id="price_range" name="price_range" placeholder="E.g. 20000" value="<?php echo e(old('price_range')); ?>" required>
                    <?php if($errors->has('price_range')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('price_range')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>   
        </div>
        <br>
    </div>
</div>