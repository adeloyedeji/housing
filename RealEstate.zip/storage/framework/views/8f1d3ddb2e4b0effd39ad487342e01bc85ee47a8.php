<div class="section property-share"> 
    <h4 class="s-property-title">Comments </h4> 

    <input type="hidden" id="comment_house" name="comment_house" value="<?php echo e(count($ad_comments)); ?>">
    <div class="row" id="commentRow">
        <?php if( count($ad_comments) > 0 ): ?>
            <?php $__currentLoopData = $ad_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12" style="padding: 10px;" id="prevComment<?php echo e($comment->id); ?>">
                    <h5><?php echo e($comment->commentOwner->fname); ?> <?php echo e($comment->commentOwner->lname); ?> 
                    <small class="pull-right"><?php echo e($comment->created_at->diffForHumans()); ?></small></h5>
                    <p class="">
                        <?php echo e($comment->comment); ?>

                    </p>
                </div>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div clss="col-md-12" style="padding: 10px;" id="prevComment">
                <h5>Comments</h5>
                <p class="">
                    No threads found.
                </p>
            </div>
        <?php endif; ?>
        <div clss="col-md-12" style="padding: 10px;" id="comment_row">
            <div class="form-group">
                <input type="hidden" id="resource" name="resource" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" id="house_ad" name="house_ad" value="<?php echo e($ad->id); ?>">
                <textarea class="form-control border-input" id="commentBox" name="commentBox" placeholder="Comments here..." style="height:200px;resize:none"></textarea>
                <p></p>
                <center>
                    <?php if(\Auth::check()): ?>
                        <input class="btn btn-finish btn-primary" id="commentBtn" value="Submit" type="submit">
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">You must be signed in to post a comment</a>
                    <?php endif; ?>
                </center>
            </div>
        </div>
    </div>
</div>