<?php $__env->startSection('title'); ?>
    | Update Password
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head"> 
    <div class="container">
        <div class="row">
            <div class="page-head-content">
                <h1 class="page-title">Hello : <span class="orange strong"><?php echo e(\Auth::user()->fname); ?> <?php echo e(\Auth::user()->lname); ?></span></h1>
            </div>
        </div>
    </div>
</div>

<div class="content-area user-profiel" style="background-color: #FCFCFC;">&nbsp;
    <div class="container">   
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 profiel-container">

                <form class="form-horizontal" method="POST" action="<?php echo e(url('profile/update')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="PUT">

                    <div class="profiel-header">
                        <h3>
                            <b>UPDATE</b> YOUR PASSWORD <br>
                            <small>Fill in the fields below to update your password.</small>
                        </h3>
                        <?php if( session()->has('status')): ?>
                            <div class="alert alert-success alert-dismissable"  id="alert_warn">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <span id="alert_warn_msg"><?php echo e(session('status')); ?></span>
                            </div>
                        <?php endif; ?>
                        <hr>
                    </div>

                    <div class="clear">

                        <div class="col-sm-10 col-sm-offset-1">
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label>Password <small>(required)</small></label>
                                <input name="password" id="password" type="password" class="form-control" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                                <label>Confirm password : <small>(required)</small></label>
                                <input type="password" name="password_confirmation" id="password-confirm" class="form-control" required>
                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div> 
                        </div>
                        <div class="col-sm-10 col-sm-offset-1">
                            <input type='submit' class='btn btn-finish btn-primary pull-right' value='Update Password' />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div><!-- end row -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>