<?php $__env->startSection('title'); ?>
    | Notification
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/lightslider.min.css')); ?>">
<div class="page-head"> 
    <div class="container">
        <div class="row">
            <div class="page-head-content">
                <h1 class="page-title">Notifications</h1>               
            </div>
        </div>
    </div>
</div>
<div class="content-area single-property" style="background-color: #FCFCFC;">&nbsp;
    <div class="container">   

        <div class="clearfix padding-top-40">
            <div class="row">
                <div class="col-md-12">
                    <?php if( count($notifications) > 0 ): ?>
                    <?php for($i = 0; $i < count($notifications); $i++): ?>
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <!--<span class="pull-right"> <?php echo e($notifications[$i]['created_at']); ?></span>-->
                                <h3>
                                    <?php echo e($notifications[$i]['data']['type']); ?>

                                </h3>
                            </div>
                            <div style="padding:10px;">
                                <b>
                                    <?php echo e($notifications[$i]['data']['message']); ?>

                                    <p></p>
                                    <?php if( count($notifications[$i]['data']) == 3 ): ?>
                                        <a class="btn btn-default" href="<?php echo e($notifications[$i]['data']['url']); ?>">View ad</a>
                                    <?php endif; ?>
                                </b>
                            </div>
                        </div>
                    <?php endfor; ?>
                    <?php else: ?>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <h3>
                                You have no new notifications
                            </h3>
                            <button class="btn btn-lg btn-block btn-default" onclick="window.location='<?php echo e(url('notification/show-old')); ?>'">View older notifications</button>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>