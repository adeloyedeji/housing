<div class="row">
    <form method="POST">
        <div class="col-md-12">
            <div class="col-md-4">
                <div class="form-group">
                    <label class="control-label" for="minimum_price">Minimum Price</label>
                    <input type="number" class="form-control border-input" id="minimum_price" name="minimum_price">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label class="control-label" for="maximum_price">Maximum Price</label>
                    <input type="number" class="form-control border-input" id="maximum_price" name="maximum_price">
                </div>
            </div>
            <div class="col-md-4">
                <p></p>
                <br>
                <p>
                    <button type="submit" class="btn btn-info btn-fill btn-wd">Search</button>
                </p>
            </div>
        </div>
    </form>
</div>