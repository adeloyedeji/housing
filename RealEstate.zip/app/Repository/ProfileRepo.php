<?php

namespace App\Repository;

use App\Interfaces\ProfileInterface;

class ProfileRepo implements ProfileInterface {
     
}