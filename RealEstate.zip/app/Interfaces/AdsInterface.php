<?php

namespace App\Interfaces;

interface AdsInterface {
    
}