<div class="dealer-section-space">
    <span>Dealer information</span>
</div>
<div class="clear">
    <div class="col-xs-4 col-sm-4 dealer-face">
        <a href="">
            <img src="<?php echo e(asset('')); ?><?php echo e($ad->user->image); ?>" class="img-circle">
        </a>
    </div>
    <div class="col-xs-8 col-sm-8 ">
        <h3 class="dealer-name">
            <a href=""><?php echo e($ad->user->fname); ?> <?php echo e($ad->user->lname); ?></a>
            <span>@</span><span><?php echo e($ad->user->username); ?></span>
        </h3>
        <div class="dealer-social-media">
            <a class="twitter" target="_blank" href="<?php echo e($ad->user->social->twitter ? $ad->user->social->twitter : '#'); ?>">
                <i class="fa fa-twitter"></i>
            </a>
            <a class="facebook" target="_blank" href="<?php echo e($ad->user->social->facebook ? $ad->user->social->facebook : '#'); ?>">
                <i class="fa fa-facebook"></i>
            </a>
            <a class="gplus" target="_blank" href="<?php echo e($ad->user->social->google ? $ad->user->social->google : '#'); ?>">
                <i class="fa fa-google-plus"></i>
            </a>     
        </div>

    </div>
</div>

<div class="clear">
    <ul class="dealer-contacts">                  
        <?php if( $ad->user->profile->current_address ): ?>
            <li><i class="pe-7s-map-marker strong"> </i> <?php echo e($ad->user->profile->current_address); ?></li>
        <?php endif; ?>
        <li><i class="pe-7s-mail strong"> </i> <?php echo e($ad->user->email); ?></li>
        <li><i class="pe-7s-call strong"> </i> <?php echo e($ad->user->profile->phone ? $ad->user->profile->phone : "NOT AVAILABLE"); ?></li>
    </ul>
    <p>
        <?php echo e($ad->user->profile->about); ?>

    </p>
</div>