<?php

namespace App\Interfaces;

interface SearchInterface {
    
}