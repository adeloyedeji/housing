<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>HOUSE MAIT <?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="HOUSE MAIT is a real-estate company">
        <meta name="author" content="Kimarotec">
        <meta name="keyword" content="html5, css, bootstrap, property, real-estate theme , bootstrap template">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'HouseMait')); ?></title>

        <!-- Styles -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.PNG')); ?>" type="image/x-icon">
        <link rel="icon" href="<?php echo e(asset('img/favicon.PNG')); ?>" type="image/x-icon">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('css/normalize.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/fontello.css')); ?>">
        <link href="<?php echo e(asset('fonts/icon-7-stroke/css/pe-icon-7-stroke.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('fonts/icon-7-stroke/css/helper.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/icheck.min_all.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/price-range.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">  
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.transitions.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker3.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/housemait.css')); ?>">
    </head>
    <body>
        <div <?php if(! active("home") ): ?>id="vue_id" <?php endif; ?>>
            <div id="preloader">
                <div id="status">&nbsp;</div>
            </div>
            <?php if(auth()->guard()->check()): ?>
            <notification :id="<?php echo e(Auth::id()); ?>"></notification>
            <audio id="noty_audio">
                <source src="<?php echo e(asset('audio/notify.mp3')); ?>">
                <source src="<?php echo e(asset('audio/notify.ogg')); ?>">
                <source src="<?php echo e(asset('audio/notify.wav')); ?>">
            </audio>
            <?php endif; ?>
            <?php echo $__env->make('layouts.partials.top-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.partials.nav-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <?php echo $__env->make('layouts.partials.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <script type="text/javascript">
            $(function() {
                
                $("#show_old").click( function() {
                    window.location = "<?php echo e(url('notification/show-old')); ?>";
                });
            });
        </script>
    </body>
</html>
